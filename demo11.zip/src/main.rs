use boa_engine::{prelude::*, property::PropertyKey, Context, JsResult, Source};
use serde_json::Value;

fn main() -> JsResult<()> {
    run_js(
        r#"
    let two = 1 + 1;
    let definitely_not_four = two + "2";
    definitely_not_four
    "#,
    );
    println!("test 1");
    run_js(
        r#"
    var data = {"cc":"sdfdsf","ds123":123,"dfsd":{"qq":"qweqw"},"dd":[1,2,3]};
    data;
    "#,
    );
    println!("test 2");
    run_js(
        r#"
    var data = [1,2,3];
    data;
    "#,
    );
    println!("test 3");
    run_js(
        r#"
    var data = ["cx1","cxk2"];
    data
    "#,
    );

    Ok(())
}

pub fn run_js(source: &str) -> Value {
    let mut context: Context = Context::default();
    // Parse the source code
    let result: JsValue = context.eval(Source::from_bytes(source)).unwrap();
    println!("run_js {:?}", result);
    println!(
        "run_js {:?}",
        js_value_to_serde_value(&result, &mut context)
    );
    Value::Null
}

fn js_value_to_serde_value(js_value: &JsValue, context: &mut Context) -> serde_json::Result<Value> {
    match js_value {
        JsValue::Undefined => Ok(Value::Null),
        JsValue::Null => Ok(Value::Null),
        JsValue::Boolean(b) => Ok(Value::Bool(*b)),
        JsValue::String(s) => Ok(Value::String(s.to_std_string().unwrap())),
        JsValue::Rational(n) => Ok(Value::Number(
            serde_json::Number::from_f64(*n).unwrap_or(serde_json::Number::from(0)),
        )),
        JsValue::Integer(i) => Ok(Value::Number(serde_json::Number::from(*i))),
        JsValue::Object(obj) => {
            println!("objbase => {:#?}", obj);
            let borrow = obj.borrow();
            let properties = borrow.properties();
            for ele in properties.index_property_values() {
                println!("index_property_values => {:?}", ele);
            }
            println!("=================1");
            for (ele, v) in properties.index_properties() {
                let get = obj.get(ele, context).unwrap();
                println!("obj => {}|{:?}|{:?}", ele, get, v);
                println!("obj2 => {:?}", js_value_to_serde_value(&get, context));
            }
            println!("=================2");
            for ele in properties.index_property_keys() {
                let get = obj.get(ele, context).unwrap();
                println!("obj => {}|{:?}", ele, get);
                println!("obj2 => {:?}", js_value_to_serde_value(&get, context));
            }
            let map = serde_json::Map::new();
            Ok(Value::Object(map))
        }
        // 处理其他可能的 JsValue 类型...
        _ => unimplemented!("Other JsValue types are not implemented yet"),
    }
}
